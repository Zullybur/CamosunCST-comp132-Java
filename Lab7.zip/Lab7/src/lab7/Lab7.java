/*
 * Add you description here
 */
package lab7;

import media.*;

/**
 *
 * @author 
 */
public class Lab7{


    public static void main(String[] args) {

       // this is my directory - change it to your directory or use filechooser as we have done in the past.
        String fileSource = "C:\\backup_smps_dec2010\\transfer\\_comp132_2015q2\\labs\\a6\\Lab6\\src\\lab6\\ladybug_sm.jpg";
        String fileTarget = "C:\\backup_smps_dec2010\\transfer\\_comp132_2015q2\\labs\\a6\\Lab6\\src\\lab6\\640x480.jpg";

        Picture source = new Picture(fileSource);
        Picture target = new Picture(fileTarget);
        
        target.copyPictureOffset(source);
        
        //source.runEffect();
        
        target.repaint();




    }
}
